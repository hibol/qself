import document from "document";
import { Accelerometer } from "accelerometer";
import { me } from "appbit";
import { display } from "display";
import { vibration } from "haptics";
import * as messaging from "messaging";
import * as fs from "fs";
import * as util from "../common/util";

var text_recordings_in_watch = document.getElementById("recordingsInWatchText");
text_recordings_in_watch.text = "";

var text_recordings_in_phone = document.getElementById("recordingsInPhoneText");
text_recordings_in_phone.text = "";

var text_recordings_in_server = document.getElementById("recordingsInServerText");
text_recordings_in_server.text = "";

let button_end_session = document.getElementById("btn-end-session");

var data = new Array();
var waiting_data_length = 0;
var timestart, timestop;
var duration;
var color;
var messages = { "sendDataToPhone":1, "askStatusFromPhone":2 ,"sendDataToServer":3, "askStatusFromServer":4 };
var statsInPhone = {};
var statsInServer = {};

let screen_home = document.getElementById("home");
let screen_go = document.getElementById("go");
let screen_settings = document.getElementById("settings");
let screen_set_timer = document.getElementById("set-timer");
let screen_end = document.getElementById("end");

let button_abdos = document.getElementById("btn-abdos");
let button_dorsaux = document.getElementById("btn-dorsaux");
let button_squats = document.getElementById("btn-squats");
let button_corde = document.getElementById("btn-corde");
let button_settings = document.getElementById("btn-settings");

let button_min = document.getElementById("btn-min");
let button_sec = document.getElementById("btn-sec");

let label_time = document.getElementById("time-label");
let label_reps = document.getElementById("reps-label");
let button_start = document.getElementById("btn-start");
let button_stop = document.getElementById("btn-stop");

let button_free = document.getElementById("btn-mode-free");
let button_timed = document.getElementById("btn-mode-timed");

let pagination_dots = document.getElementById("pagination-dots");

let seconds = 0, minutes = 0, goal_minutes = 3, goal_seconds = 0, t;
let counting = false;

var screen = "home"; // settings,set_timer, go, end
var mode = "free";   // free, timed
var time_set = "minutes"; // seconds
var sport = "abdos"  // dorsaux, squats, corde

var accelerometer = new Accelerometer({ frequency: 5 });

var reps = 0;
var x = 0, y = 0, z = 0, x_old = 0, y_old = 0, z_old = 0;
var m = 0, m_old = 0;
var init, init_time, now;

var temp_read;
try {
  temp_read = fs.readFileSync("test.txt", "ascii");
  temp_read = temp_read.split("+");
  for(var i = 0; i < temp_read.length; i++) {
    data.push(temp_read[i]);
    console.log(temp_read[i]);
  }
  fs.unlinkSync("test.txt");  // delete the file
} catch(e) {
  console.log('Oh snap we have an error: ', e);
}

updateRecordingsInWatch(data);

function showGoScreen() {  
  console.log("Show go screen");
  screen_go.style.display = "inline";
  screen_home.style.display = "none";
  screen_settings.style.display = "none";
  screen_set_timer.style.display = "none";
  screen_end.style.display = "none";
  pagination_dots.style.display = "none";
  
  screen = "go";
  
  display.autoOff = false;
  
  label_reps.textContent = "...";
  
  if (mode=="timed") {
    minutes = goal_minutes;
    seconds = goal_seconds;
    
    if (seconds <= 10 && minutes == 0) {
      label_time.style.fill = color;
    } else {
      label_time.style.fill = "white";
    }
    
    updateTime();
  } else if (mode=="free") {
    minutes = 0;
    seconds = 0;
    updateTime();
  }
}

function showHomeScreen() {
  console.log("Show home screen");
  screen_go.style.display = "none";
  screen_home.style.display = "inline";
  screen_settings.style.display = "none";
  screen_set_timer.style.display = "none";
  screen_end.style.display = "none";
  pagination_dots.style.display = "inline";
  
  screen = "home";
  
  display.autoOff = true;
  
  if (mode=="free") {
    seconds = 0;
    minutes = 0;
  } else if (mode=="timed") {
    seconds = goal_seconds;
    minutes = goal_minutes;
  }
  reps = 0;
  x_old = 0, y_old = 0, z_old = 0;
  vibration.stop();
}

function showSettingsScreen() {
  console.log("Show settings screen");
  screen_go.style.display = "none";
  screen_home.style.display = "none";
  screen_settings.style.display = "inline";
  screen_set_timer.style.display = "none";
  screen_end.style.display = "none";
  pagination_dots.style.display = "none";
  
  screen = "settings";
}

function showSetTimerScreen() {
  console.log("Show settings screen");
  screen_go.style.display = "none";
  screen_home.style.display = "none";
  screen_settings.style.display = "none";
  screen_set_timer.style.display = "inline";
  screen_end.style.display = "none";
  pagination_dots.style.display = "none";
  
  screen = "set_timer";
  
  button_min.text = util.monoDigits(pad(goal_minutes));
  button_sec.text = util.monoDigits(pad(goal_seconds));
  time_set = "minutes";
}

function showEndScreen() {
  console.log("Show end screen");
  screen_go.style.display = "none";
  screen_home.style.display = "none";
  screen_settings.style.display = "none";
  screen_set_timer.style.display = "none";
  screen_end.style.display = "inline";
  pagination_dots.style.display = "none";
  
  screen = "end";
}

function timerStart() {
  console.log("timer start");
  t = setInterval(tick, 1000);
}

function timerStop() {
  console.log("timer stop");
  clearInterval(t);
}

function tick() {  
  if (mode=="free") {
    seconds++;
    if (seconds >= 60) {
        seconds = 0;
        minutes++;
    }
  } else if (mode=="timed") {
    seconds--;
    
    if (seconds <= 10 && minutes == 0) {
      label_time.style.fill = color;
    } else {
      label_time.style.fill = "white";
    }
    if (seconds <= 0) {
      if (minutes >= 1) {
        seconds = 59;
        minutes--;
      } else {
        vibration.start("ring");
        stopSerie();
      }
    }
  }
  updateTime();
}

function updateTime() {
  label_time.textContent = util.monoDigits(pad(minutes)) + ":" + util.monoDigits(pad(seconds));
}

function updateReps() {
  label_reps.textContent = util.monoDigits(pad(reps));
}

button_start.onclick = function (){
  init = true;
  if (counting==false) {
    button_start.text = "Pause"
    accelerometer.start();
    timestart = new Date;
  } else {
    timerStop();
    counting=false;
    button_start.text = "Start"
    accelerometer.stop();
  }
}

button_stop.onclick = function (){
  stopSerie();
}

function stopSerie() {
  timerStop();
  counting=false;
  accelerometer.stop();
  button_start.text = "Start";
  
  timestop = new Date;
  
  if (mode=="free") {
    duration = seconds + minutes*60;
  } else if (mode=="timed") {
    duration = goal_seconds + goal_minutes*60 - seconds - minutes*60; // in case the exercise was stopped before the end of the timer
  }
  
  if (timestart != null) {
    var last_data = new Array(timestart.toJSON(), timestop.toJSON(), duration, reps, sport);
    console.log(last_data.toString());
    console.log(last_data.toString().length*8);
    data.push(last_data.toString());
    updateRecordingsInWatch(data);
    
    reps = 0;
    updateReps()
  
    showEndScreen();
    setTimeout(function(){ showHomeScreen(); }, 1000);
  } else {
    showHomeScreen();
  }
  

}

accelerometer.onreading = function() {
  x = accelerometer.x ? accelerometer.x : 0;
  y = accelerometer.y ? accelerometer.y : 0;
  z = accelerometer.z ? accelerometer.z : 0;
  console.log("Acc: " + accelerometer.x.toFixed(2) + " " + accelerometer.y.toFixed(2) + " " + accelerometer.z.toFixed(2));
  
  if (counting==false) {
    if (init==true) {
      console.log("waiting for stabilization");
      init_time = new Date();
      init = false;
    } else {
      now = new Date();
      
      if (x-x_old > 2 || y-y_old > 2 || z-z_old > 2) {
        init_time = new Date();
      }
      
      if(now-init_time > 2000) {
        counting = true;
        timerStart();
        updateReps();
        console.log("start counting");
        vibration.start("ring");
        setTimeout(function(){ vibration.stop(); }, 1000);
      }
    }    
  } else {
    switch (sport) {
      case "abdos":
        detectAbdos();
      break;
      case "dorsaux":
        detectDorsaux();
      break;
      case "squats":
        detectSquats();
      break;
      case "corde":
        detectCorde();
      break;
    }
  }
  
  x_old = x;
  y_old = y;
  z_old = z;
}

function detectAbdos() {
  m_old = (x_old + y_old)
  m = (x + y)
  if (m_old < 0 && m > 0) {
    reps++;
    console.log("abdos : " + reps);
    updateReps();
  }
}

function detectSquats() {
  m_old = (x_old + y_old)
  m = (x + y)
  if (m_old > -15 && m < -15) {
    reps++;
    console.log("squats : " + reps);
    updateReps();
  }
}

function detectDorsaux() {
  m_old = (x_old + z_old)
  m = (x + z)
  if (m_old < 4  && m > 4) {
    reps++;
    console.log("dorsaux : " + reps);
    updateReps();
  }
}

function detectCorde() {
  if (y_old < 0  && y > 0) {
    reps++;
    console.log("corde : " + reps);
    updateReps();
  }
}

button_min.onclick = function (){
  if (time_set=="minutes") {
    
  } else if (time_set=="seconds") {
    time_set = "minutes";
    button_sec.style.fill = "fb-white";
    button_min.style.fill = "fb-blue";
  }
}

button_sec.onclick = function (){
  if (time_set=="minutes") {
    time_set = "seconds";
    button_sec.style.fill = "fb-blue";
    button_min.style.fill = "fb-white";
  } else if (time_set=="seconds") {
    
  }
}

button_settings.onclick = function() {
  showSettingsScreen();
}

button_free.onclick = function() {
  mode = "free";
  showHomeScreen();
  minutes = 0;
  seconds = 0;
  updateTime();
}

button_timed.onclick = function() {
  mode = "timed";
  showSetTimerScreen();
}

button_abdos.onclick = function() {
  sport = "abdos";
  color = "#F1038A";
  button_start.style.fill = color;
  button_stop.style.fill = color;
  showGoScreen();
}

button_dorsaux.onclick = function() {
  sport = "dorsaux";
  color = "#9410E7";
  button_start.style.fill = color;
  button_stop.style.fill = color;
  showGoScreen();
}

button_squats.onclick = function() {
  sport = "squats";
  color = "#07C8E3";
  button_start.style.fill = color;
  button_stop.style.fill = color;
  showGoScreen();
}

button_corde.onclick = function() {
  sport = "corde";
  color = "#3D21E9";
  button_start.style.fill = color;
  button_stop.style.fill = color;
  showGoScreen();
}

button_end_session.onclick = function (){  
  if (waiting_data_length != 0) {
    sendDataToPhone();
    data = new Array();
    timestart = null;
  }
}

function formatDate(d) {
  let year = d.getFullYear();
  let month = d.getMonth()+1;
  let day = d.getDate();
  let hours = d.getHours();
  let minutes = d.getMinutes();
  let seconds = d.getSeconds();

  return pad(day) + "." + pad(month) + "." + year + " " + pad(hours) + ":" + pad(minutes) + ":" + pad(seconds);
}

function pad(n) {
    return n<10 ? "0"+n : n;
}

// manage physical buttons
document.onkeypress = function(e) {
  console.log("Key pressed: " + e.key);
  e.preventDefault();
  if (e.key==="back") {
    switch (screen) {
      case "home":
        // save any unexported data before leaving
        if (data.length != 0) {
          console.log("Some data has not been exported");
          try {
            console.log("Data: " + data.join("+"));
            fs.writeFileSync("test.txt", data.join("+"), "ascii");
          } catch(e) {
            console.log('Oh snap we have an error: ', e);
          }
        }
        me.exit();
        console.log("exit");
        break;
      case "settings":
      case "go":
        showHomeScreen();
        console.log("back to home");
        break;
      case "set_timer":
        showHomeScreen();
        seconds = goal_seconds;
        minutes = goal_minutes;
        break;
    }   
  }
  if (e.key==="up") {
    switch(screen) {
      case "set_timer":
        if (time_set=="minutes") {
          goal_minutes += 1;
          button_min.text = util.monoDigits(pad(goal_minutes));
        } else if (time_set=="seconds") {
          goal_seconds += 5;
          if (goal_seconds >= 60) {
              goal_seconds = 0;
          }
          button_sec.text = util.monoDigits(pad(goal_seconds));
        }
        console.log("++");
        break;
    }
  }
  if (e.key==="down") {
    switch(screen) {
      case "set_timer":
        if (time_set=="minutes") {
          goal_minutes -= 1;
          if (goal_minutes <0) {
            goal_minutes = 0;
          }
          button_min.text = pad(goal_minutes);
        } else if (time_set=="seconds") {
          goal_seconds -= 5;
          if (goal_seconds <= 0) {
              goal_seconds = 55;
          }
          button_sec.text = pad(goal_seconds);
        }
        console.log("++");
        break;
    }
  }
}

function updateRecordingsInWatch() {
  text_recordings_in_watch.text = "";
  waiting_data_length = data.length;
  if (waiting_data_length == 0) {
    button_end_session.text = "Pas de données";
    button_end_session.style.fill = "black";
    text_recordings_in_watch.text =  "";
  } else {
    var text = waiting_data_length==1 ? " exercice" : " exercices";
    text_recordings_in_watch.text =  "Données prêtes : " + waiting_data_length + text;
    button_end_session.text = "Envoyer données";
    button_end_session.style.fill = "fb-blue";
  }
}

// ------ Code for sending messages --------------
messaging.peerSocket.onopen = function() {
  console.log("App - device socket open");
  messaging.peerSocket.send([messages["askStatusFromPhone"]]);
  messaging.peerSocket.send([messages["askStatusFromServer"]]);
}

messaging.peerSocket.onerror = function(err) {
  console.log("App - Connection error: " + err.code + " - " + err.message);
}

function sendDataToPhone() {
  console.log("sendDataToPhone called");
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {        // check the state of the connection
    if (data.length > 0) {                              // check if there are data to send
        
      console.log("Sending data to phone... ");

      for (let i=0; i < data.length; i+=1) {
        let toSend = [messages["sendDataToPhone"], data[i]];
        messaging.peerSocket.send(toSend);
      }
    }
  } else {
    console.log("Connection error");
  }
}

function sendDataToServer() {
  console.log("sendDataToServer called");
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {        // check the state of the connection
    console.log("Asking phone to send to server");
    let toSend = [messages["sendDataToServer"]];
    messaging.peerSocket.send(toSend);
  } else {
    statusLabel.text = "Connection error";
  }
}

// ------ Code for receiving messages ------------
messaging.peerSocket.onmessage = function(evt) {
  let answer = evt.data;
  console.log("Answer received = " + answer);
  
  let message = answer[0];    // The first element is the type of message
  
  switch(message) {
      
    case messages["sendDataToPhone"]:
      break;
      
    case messages["askStatusFromPhone"]:
      text_recordings_in_phone.text = "Envoyé au compagnon : ";
      var text = answer[1]==1 ? " exercice" : " exercices";
      text_recordings_in_phone.text += answer[1] + text;
      console.log("Updated recordings_in_phone_text");
      
      sendDataToServer();
      break;
      
    case messages["sendDataToServer"]:
      break;
      
    case messages["askStatusFromServer"]:
      statsInServer = answer[1][1];
      
      if (statsInServer != 0) {
        console.log(statsInServer);
        console.log("envoi au serveur OK")
        text_recordings_in_server.text = "Envoi au serveur OK";
        button_end_session.text = "Données transmises";
        button_end_session.style.fill = "fb-green";
      } else {
        console.log("erreur serveur")
        text_recordings_in_server.text = "Erreur serveur ";
        button_end_session.text = "Réessayer";
        button_end_session.style.fill = "fb-red";
      }
      break;      
  }
}