var reps = 0;
var x = 0, y = 0, z = 0, x_old = 0, y_old = 0, z_old = 0;


accelerometer.onreading = function() {
  x = accelerometer.x ? accelerometer.x.toFixed(2) : 0;
  y = accelerometer.y ? accelerometer.y.toFixed(2) : 0;
  z = accelerometer.z ? accelerometer.z.toFixed(2) : 0;
  console.log("Current acceleration: " + x + " " + y + " " + z);
  
  switch (sport) {
    case "abdos":
      detectAbdos();
    break;
    case "dorsaux":
    break;
    case "squats":
    break;
    case "corde":
    break;
  }
  
  x_old = x;
  y_old = y;
  z_old = z;
}

function detectAbdos() {
  if (x_old < 0 and x > 0) {
    reps++;
    console.log("abdo : " + reps);
  }
}

function detectDorsaux() {
  
}

function detectSquats() {
  
}

function detectCorde() {
  
}